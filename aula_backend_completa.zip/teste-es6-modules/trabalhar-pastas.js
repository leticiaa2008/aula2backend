// 📂 trabalhar-pastas.js
const fs = require('fs').promises;

// 🔧 Função para criar uma pasta
async function criarPasta(nomePasta) {
  try {
    console.log(`📁 Criando pasta "${nomePasta}"...`);

    // Criar a pasta
    await fs.mkdir(nomePasta);

    console.log(`✅ Pasta "${nomePasta}" criada com sucesso!`);

  } catch (error) {
    if (error.code === 'EEXIST') {
      console.log(`⚠️ A pasta "${nomePasta}" já existe.`);
    } else {
      console.error(`❌ Erro ao criar pasta:, error.message`);
    }
  }
}

// 🔎 Função para listar arquivos de uma pasta
async function listarArquivos(nomePasta) {
  try {
    console.log(`📂 Listando arquivos da pasta "${nomePasta}"...`);

    // Ler conteúdo da pasta
    const arquivos = await fs.readdir(nomePasta);

    if (arquivos.length === 0) {
      console.log('(pasta vazia!)');
    } else {
      arquivos.forEach((arquivo, index) => {
        console.log(`   ${index + 1}. ${arquivo}`);
      });
    }

    // Código continua normalmente aqui

  } catch (error) {
    console.error(`❌ Erro ao listar pasta "${nomePasta}":, error.message`);
  }
}

// 🚀 Função principal
async function exemploComPastas() {
  console.log('\n--- TRABALHANDO COM PASTAS ---\n');

  // Criar uma pasta de teste
  await criarPasta('minha-pasta-teste');
  console.log('');

  // Listar arquivos da pasta atual
  await listarArquivos('.');
  console.log('');

  // Listar arquivos da pasta que criamos
  await listarArquivos('minha-pasta-teste');

  console.log('\n--- EXEMPLO CONCLUÍDO ---');
}

// ▶️ Executar o exemplo
exemploComPastas();