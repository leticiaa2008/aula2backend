// pessoa.js - Como um "supermercado" variado de exports

// JEITO 1: Exportar itens individuais
export const nome = 'João';
export const idade = 30;
export function falar() {
  return `Olá, eu sou ${nome}`;
}

// JEITO 2: Exportar um item "principal"
export default {
  nome: 'João',
  idade: 30,
  falar() {
    return `Olá, eu sou ${this.nome}`;
  }
};
