// 🥖 PASSO 1: Pegar nosso molde de produto
const Product = require('./models/Product');

// 🥖 PASSO 2: Criar um pão francês usando o molde
const paoFrances = new Product(
  1,                      // Número da fichinha
  'Pão Francês',          // Nome do pão
  'Pão fresquinho do dia',// O que tem de especial
  0.50,                   // Quanto custa (50 centavos)
  1,                      // Que tipo é (1 = Pães)
  'pao-frances.jpg'       // Foto do pão
);

// 🎯 PASSO 3: Vamos ver como ficou!
console.log('Preço bonitinho:', paoFrances.getFormattedPrice()); // "R$ 0,50"
console.log('Está disponível?', paoFrances.isAvailable());       // true

// 🎉 Pronto! Nossa fichinha de pão está funcionando!

// 📦 PASSO 1: Pegar nosso molde de seção
const Category = require('./models/Category');

// 📦 PASSO 2: Criar a seção de pães
const secaoPaes = new Category(
  1,                          // Número da seção
  'Pães',                     // Nome da seção
  'Pães frescos e quentinhos',// O que tem de especial
  '🍞'                        // Emoji da seção
);

// 🎯 PASSO 3: Vamos colocar um produto na seção!
secaoPaes.addProduct(); // Colocamos 1 pão
console.log('Quantos produtos temos?', secaoPaes.productCount); // 1

// 🎉 Pronto! Nossa seção de pães está funcionando!