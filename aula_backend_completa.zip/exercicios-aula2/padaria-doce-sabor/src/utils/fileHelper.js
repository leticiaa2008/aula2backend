// 📁 Pegamos as ferramentas que vamos usar
const fs = require('fs').promises; // Para mexer com arquivos
const path = require('path');      // Para trabalhar com endereços

// 🧰 Nosso assistente para arquivos
// static = funções que funcionam sem precisar criar um objeto primeiro
class FileHelper {
  // 📄 PASSO 1: Função para LER um arquivo JSON (como ler uma receita)
  static async readJSON(filePath) {
    try {
      // Lê o arquivo como se fosse um texto normal
      const data = await fs.readFile(filePath, 'utf8');
      // JSON serve para "traduzir" texto em informações que o computador entende
      // É como pegar uma receita escrita à mão e digitar no computador!
      return JSON.parse(data);
    } catch (error) {
      console.error('❌ Robô: "Ops! Não consegui ler este arquivo."', error);
      return null; // Retorna "nada" se deu erro
    }
  }

  // ✏️ PASSO 2: Função para ESCREVER um arquivo JSON (como escrever uma receita)
  static async writeJSON(filePath, data) {
    try {
      // JSON.stringify = "tradutor" que transforma informações do computador em texto
      // É como gerar uma lista no computador e imprimir numa folha de papel!
      const jsonData = JSON.stringify(data, null, 2);
      // Salva o texto no arquivo (como guardar a receita numa gaveta)
      await fs.writeFile(filePath, jsonData, 'utf8');
      return true; // Deu certo!
    } catch (error) {
      console.error('❌ Robô: "Ops! Não consegui salvar este arquivo."', error);
      return false; // Deu erro!
    }
  }

  // 🗂️ Função para CRIAR uma pasta (se não existir)
  static async ensureDirectory(dirPath) {
    try {
      // Cria a pasta e todas as pastas "de dentro" se precisar
      // (ex.: cria /minha/pasta/teste mesmo que uma das outras não exista)
      await fs.mkdir(dirPath, { recursive: true });
      return true;
    } catch (error) {
      console.error('❌ Robô: "Ops! Não consegui criar a pasta."', error);
      return false; // Deu erro!
    }
  }
}

// 🧰 PASSO 4: Deixa outros arquivos usarem nosso "assistente de arquivos"
module.exports = FileHelper;