// criando_produto.js
// Esse arquivo cria uma "fichinha" de produto

// Passo 1: Criamos a "classe" (o molde)
class Produto {
  // Passo 2: O "construtor" é quem preenche a fichinha
  // quando criamos um novo produto, ele vai receber as informações
  constructor(id, nome, descricao, preco, categoria, imagem) {
    // Passo 3: Guardamos as informações no produto
    this.id = id;                    // ID do produto (ex: 1, 2, 3...)
    this.nome = nome;                // Nome do produto (ex: "Camiseta")
    this.descricao = descricao;      // Descrição do produto (ex: "100% algodão")
    this.preco = preco;              // Preço do produto (ex: 49.90)
    this.categoria = categoria;      // Categoria (ex: "Roupas")
    this.imagem = imagem;            // Imagem do produto (ex: "camiseta.png")
    this.available = true;           // Produto disponível (por padrão: sim)
    this.updated = new Date();       // Data da última atualização (agora)
  }

  // Passo 4: Funções úteis para trabalhar com o produto

  // Função para listar os dados (transforma em JSON)
  toJSON() {
    return {
      id: this.id,
      nome: this.nome,
      descricao: this.descricao,
      preco: this.preco,
      categoria: this.categoria,
      imagem: this.imagem,
      available: this.available,
      updated: this.updated,
    };
  }

  // Função para mudar informações do produto
  atualizar(novosDados) {
    if (novosDados.nome) this.nome = novosDados.nome;
    if (novosDados.descricao) this.descricao = novosDados.descricao;
    if (novosDados.preco) this.preco = novosDados.preco;
    if (novosDados.categoria) this.categoria = novosDados.categoria;
    if (novosDados.imagem) this.imagem = novosDados.imagem;
    if (typeof novosDados.available === "boolean")
      this.available = novosDados.available;

    this.updated = new Date();
  }

  // Função para mostrar o preço bonitinho (R$, 1,99)
  getPrecoFormatado() {
    return `R$ ${this.preco.toFixed(2).replace('.', ',')}`;
  }

  // Função para ver se o produto está disponível
  estaDisponivel() {
    return this.available === true;
  }
}

// Passo 5: Deixa outros arquivos usarem essa "fichinha"
module.exports = Produto;

