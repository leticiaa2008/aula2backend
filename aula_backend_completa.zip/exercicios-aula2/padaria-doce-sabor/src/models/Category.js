// 🥖 PASSO 1: Criando o molde de uma "seção" da padaria
class Category {
  // 🥖 PASSO 2: Função que roda quando criamos uma nova seção
  constructor(id, name, description, icon) {
    this.id = id;              // Número da seção (1, 2, 3...)
    this.name = name;          // Nome da seção ("Pães", "Bolos"...)
    this.description = description;  // O que tem nesta seção
    this.icon = icon;          // Emoji da seção 🥐🍞🎂

    // 🥖 Informações que o computador preenche sozinho
    this.active = true;        // Seção está funcionando?
    this.createdAt = new Date(); // Quando foi criada
    this.productCount = 0;     // Quantos produtos tem aqui
  }

  // 🥖 PASSO 3: Funções úteis para trabalhar com a seção

  // Função para salvar no arquivo (transforma em JSON)
  toJSON() {
    // JSON é como uma "lista organizada" que o computador entende
    return {
      id: this.id,
      name: this.name,
      description: this.description,
      icon: this.icon,
      active: this.active,
      createdAt: this.createdAt,
      productCount: this.productCount
    };
  }

  // Função para mudar informações da seção
  update(newData) {
    // Só muda o que a pessoa mandou mudar
    if (newData.name) this.name = newData.name;               // Novo nome?
    if (newData.description) this.description = newData.description; // Nova descrição?
    if (newData.icon) this.icon = newData.icon;               // Novo emoji?
    if (newData.active !== undefined) this.active = newData.active; // Ativar/desativar?
  }

  // Função para quando colocamos um produto na seção
  addProduct() {
    this.productCount++; // Conta +1 produto
  }

  // Função para quando tiramos um produto da seção
  removeProduct() {
    if (this.productCount > 0) {
      this.productCount--; // Conta -1 produto (se tiver algum)
    }
  }
}

// 🥖 PASSO 4: Deixa outros arquivos usarem esta "fichinha de seção"
module.exports = Category;

